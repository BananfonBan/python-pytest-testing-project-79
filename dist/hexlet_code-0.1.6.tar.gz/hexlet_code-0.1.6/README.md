### Hexlet tests and linter status:
[![Actions Status](https://github.com/BananfonBan/python-pytest-testing-project-79/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BananfonBan/python-pytest-testing-project-79/actions)
#### How it works?
[asciinema1](https://asciinema.org/a/ESqJBO0REElVMzezxnoeTu7eM)
[asciinema2](https://asciinema.org/a/22oPjc9F0qqPE4ei88W3QhBKm)
[asciinema3](https://asciinema.org/a/8k88zOVCxZZ0IxFDtPCi7PbmG)
[asciinema4](https://asciinema.org/a/IllJxRlSEFHVFFi6yqlc8V56x)