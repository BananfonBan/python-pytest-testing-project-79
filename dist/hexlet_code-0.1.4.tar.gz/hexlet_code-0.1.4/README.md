### Hexlet tests and linter status:
[![Actions Status](https://github.com/BananfonBan/python-pytest-testing-project-79/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BananfonBan/python-pytest-testing-project-79/actions)
#### How it works?
[asciinema](https://asciinema.org/a/ESqJBO0REElVMzezxnoeTu7eM)