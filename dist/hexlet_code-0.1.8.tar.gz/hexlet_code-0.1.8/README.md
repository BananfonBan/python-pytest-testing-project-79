### Hexlet tests and linter status:
[![Actions Status](https://github.com/BananfonBan/python-pytest-testing-project-79/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/BananfonBan/python-pytest-testing-project-79/actions)
### Codeclimate test
[![Maintainability](https://api.codeclimate.com/v1/badges/e1c9fb7214d0331711ad/maintainability)](https://codeclimate.com/github/BananfonBan/python-pytest-testing-project-79/maintainability)

[![Test Coverage](https://api.codeclimate.com/v1/badges/e1c9fb7214d0331711ad/test_coverage)](https://codeclimate.com/github/BananfonBan/python-pytest-testing-project-79/test_coverage)

[![Action Status](https://github.com/BananfonBan/python-pytest-testing-project-79/actions/workflows/my-workflow.yml/badge.svg)](https://github.com/BananfonBan/python-pytest-testing-project-79/actions)

#### How it works?
[asciinema1](https://asciinema.org/a/ESqJBO0REElVMzezxnoeTu7eM)
[asciinema2](https://asciinema.org/a/22oPjc9F0qqPE4ei88W3QhBKm)
[asciinema3](https://asciinema.org/a/8k88zOVCxZZ0IxFDtPCi7PbmG)
[asciinema4](https://asciinema.org/a/IllJxRlSEFHVFFi6yqlc8V56x)